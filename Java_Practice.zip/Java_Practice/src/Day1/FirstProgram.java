package Day1;

public class FirstProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello Java");

	}

}
